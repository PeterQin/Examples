using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;
using System.Xml;

namespace WCFService
{
    public delegate void delegate_Output(string aMsg);

    

    [ServiceBehaviorAttribute(InstanceContextMode = InstanceContextMode.Single)]
    //[DeliveryRequirements(TargetContract = typeof(IMyService), RequireOrderedDelivery = true)]
    class MyService : IMyService
    {
        delegate_Output FOutput;
        public void Init(delegate_Output aOutput)
        {
            FOutput = aOutput;
        }

        #region IMyService Members

        public string Test()
        {
            return "Test return from Service at " + DateTime.Now.ToString();
        }

        #endregion
    }
}
